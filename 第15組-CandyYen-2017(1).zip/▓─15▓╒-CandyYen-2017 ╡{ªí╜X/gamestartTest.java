
import javax.swing.JFrame;

public class gamestartTest {
	   public static void main(String[] args)
	   { 
		  gamestart games = new gamestart(); 
		  games.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		  games.setSize(600, 500); 
	      games.setVisible(true); 
	   } 
}
