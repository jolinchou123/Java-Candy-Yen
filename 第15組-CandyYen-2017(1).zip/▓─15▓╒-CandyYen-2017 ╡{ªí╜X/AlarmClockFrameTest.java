
import javax.swing.JFrame;

public class AlarmClockFrameTest {
	public void runn() {
	      AlarmClockFrame alarmClockFrame = new AlarmClockFrame(); 
	      alarmClockFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      alarmClockFrame.setSize(250, 250); 
	      alarmClockFrame.setVisible(true); 
	}
}
